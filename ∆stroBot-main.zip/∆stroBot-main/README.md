## MornigStar
WHATSAPP BOT PARA TERMUX


<img src = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNo9YBQYjx1xke4J8Ez-SuRBaxiyjfnJWtEg&usqp=CAU" width="320">




## INSTALAÇÃO

# TERMUX
```bash
> Baixe O Termux
> Abra E Digite:
> apt update && apt upgrade
> pkg install git
> git clone https://github.com/FrostyGekyume/MornigStar
> cd MornigStar
> bash install.sh
> node index.js
> Escaneie O Código E Pronto!
```


# FUNÇÕES

| FUNCIONA       |               FUNÇÕES     |
| :-----------: | :--------------------------------:  |
|       ✅       | IGSTALK                           |
|       ✅       | STICKER                           |
|       ✅       | ESCREVER                          |
|       ✅       | JAPA/JAPO                         |
|       ✅       | ANIME                             |
|       ✅       | LETRA                             |
|       ✅       | CRIPTO                            |

## EM BREVE MAIS OPÇÕES




## AGRADECIMENTOS
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)
* [`botst4rz`](https://github.com/Bintang73/botst4rz)
* [`ibnusyawall`](https://github.com/ibnusyawall)
* [`alfbot`](https://github.com/alfiansx/alfbot)
